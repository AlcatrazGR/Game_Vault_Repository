-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2014 at 07:54 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `3071_3221_3223_3301`
--
CREATE DATABASE IF NOT EXISTS `3071_3221_3223_3301` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `3071_3221_3223_3301`;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `ACCOUNT_TYPE` varchar(7) NOT NULL,
  `USERNAME` varchar(20) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `EMAIL` varchar(40) NOT NULL,
  `SEX` varchar(7) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `USER_PHOTO` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`ACCOUNT_TYPE`, `USERNAME`, `PASSWORD`, `EMAIL`, `SEX`, `BIRTH_DATE`, `USER_PHOTO`) VALUES
('admin', 'Alcatraz', '123456789alcatraz', 'alcatrazgr0@gmail.com', 'male', '1991-12-22', ''),
('admin', 'Alcatraz', '123456789alcatraz', 'alcatrazgr0@gmail.com', 'male', '1991-12-22', ''),
('user', 'vasilis', '123', 'sdsada@hotmail.com', 'male', '0000-00-00', 'parthenon.jpg'),
('user', 'necrolic', '125necro', 'kenzoid@hotmail.com', 'male', '2000-11-01', '10442394_10202967323236739_1295525288439634854_n.jpg'),
('admin', 'Lena', 'lena12345', 'lenaAlvarez@gmail.com', 'female', '1993-12-19', ''),
('admin', 'Lena', 'lena12345', 'lenaAlvarez@gmail.com', 'female', '1993-12-19', '');

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
CREATE TABLE IF NOT EXISTS `games` (
  `GAME_TITLE` varchar(60) NOT NULL,
  `MIN_REQUIRE` text NOT NULL,
  `MAX_REQUIRE` text NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `IMAGE` varchar(50) NOT NULL,
  `PLATFORM` varchar(15) NOT NULL,
  `CATEGORY` varchar(20) NOT NULL,
`GAME_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `games`
--
ALTER TABLE `games`
 ADD PRIMARY KEY (`GAME_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
MODIFY `GAME_ID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
