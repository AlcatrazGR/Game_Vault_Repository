-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 25 Δεκ 2014 στις 09:16:24
-- Έκδοση διακομιστή: 5.6.20
-- Έκδοση PHP: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Βάση δεδομένων: `3071_3221_3223_3301`
--
CREATE DATABASE IF NOT EXISTS `3071_3221_3223_3301` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `3071_3221_3223_3301`;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `ACCOUNT_TYPE` varchar(7) NOT NULL,
  `USERNAME` varchar(20) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `EMAIL` varchar(40) NOT NULL,
  `SEX` varchar(7) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `USER_PHOTO` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `accounts`
--

INSERT INTO `accounts` (`ACCOUNT_TYPE`, `USERNAME`, `PASSWORD`, `EMAIL`, `SEX`, `BIRTH_DATE`, `USER_PHOTO`) VALUES
('admin', 'Alcatraz', '123456789alcatraz', 'alcatrazgr0@gmail.com', 'male', '1991-12-22', ''),
('admin', 'Alcatraz', '123456789alcatraz', 'alcatrazgr0@gmail.com', 'male', '1991-12-22', ''),
('user', 'vasilis', '123', 'sdsada@hotmail.com', 'male', '0000-00-00', 'parthenon.jpg'),
('user', 'necrolic', '125necro', 'kenzoid@hotmail.com', 'male', '2000-11-01', '10442394_10202967323236739_1295525288439634854_n.jpg'),
('admin', 'Lena', 'lena12345', 'lenaAlvarez@gmail.com', 'female', '1993-12-19', ''),
('admin', 'Lena', 'lena12345', 'lenaAlvarez@gmail.com', 'female', '1993-12-19', '');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `games`
--

DROP TABLE IF EXISTS `games`;
CREATE TABLE IF NOT EXISTS `games` (
  `GAME_TITLE` varchar(60) NOT NULL,
  `MIN_REQUIRE` longtext NOT NULL,
  `MAX_REQUIRE` longtext NOT NULL,
  `DESCRIPTION` longtext NOT NULL,
  `IMAGE` varchar(50) NOT NULL,
  `PLATFORM` varchar(15) NOT NULL,
  `CATEGORY` varchar(20) NOT NULL,
  `VIDEO_URL` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `games`
--

INSERT INTO `games` (`GAME_TITLE`, `MIN_REQUIRE`, `MAX_REQUIRE`, `DESCRIPTION`, `IMAGE`, `PLATFORM`, `CATEGORY`, `VIDEO_URL`) VALUES
('Gothic 2', '* Windows 2000/XP/XP64\r\n* 500MB RAM\r\n* Intel Pentium 4\r\n* Direct3D graphics card with at least 64MB and Shader Model 1.1', '* Windows 2000/XP/XP64\r\n* 1024MB RAM\r\n* Intel Pentium 4 / AMD CPU 2GHz or equivalent\r\n* Direct3D compatible graphics card with at least 128MB and Shader Model 1.4', 'The Nameless Hero is instructed by Xardas on the new danger, an army of evil that has gathered in the mine valley, led by dragons. Xardas sends the Hero to Lord Hagen, leader of the paladins, to retrieve the Eye of Innos, an artifact which makes it possible to speak with the dragons and learn more about their motivation. The Nameless Hero starts to the City of Khorinis and after he found a way to enter the city, he learns he has to join one of the factions – the militia, the fire mages or the mercenaries – to be permitted entrance to Lord Hagen.', 'gothic2.jpg', 'pc', 'roleplaying', 'http://youtu.be/gk6mBpSMBuk'),
('', '', '', '', '', '', '', ''),
('Gothic 3', '* Windows 2000/XP/XP64\r\n* 1024MB RAM\r\n* Intel Pentium 4 / AMD CPU 2GHz or equivalent\r\n* Direct3D compatible graphics card with at least 128MB and Shader Model 1.4', '* Windows 2000/XP/XP64\r\n* 1.5GB RAM\r\n* Intel Pentium 4 / AMD CPU 3GHz or equivalent\r\n* ATI X1600 or better, GeForce 6800 or better, at least 256MB', 'The third part opens with the Nameless Hero and his friends sailing to a new continent overrun with orcs, arriving in the Myrtana, the central region of the continent.', 'gothic3.jpg', 'pc', 'roleplaying', 'http://youtu.be/SADhUCqyd4U'),
('Arx Fatalis', '*CPU: Intel Pentium II 500 MHz\r\n*RAM: 64MB RAM	\r\n*VGA: 16MB DirectX 8.0-compatible Video Card\r\n*DX: DirectX 8				\r\n*OS: Windows 98/ME/2000/XP\r\n*HDD: 750MB Hard Drive Space\r\n*Sound: DirectX 8.0-compatible Sound Card\r\n*ODD: 4X CD-ROM		\r\n', '*CPU: Intel Pentium III 900 MHz\r\n*RAM: 256MB RAM\r\n*VGA: 32MB DirectX 8.0-compatible Video Card\r\n*DX: DirectX 8\r\n*OS: Windows 98/ME/2000/XP\r\n*HDD: 750MB Hard Drive Space\r\n*Sound: DirectX 8.0-compatible Sound Card\r\n*ODD: 4X CD-ROM', 'Arx Fatalis (lat. "fatal fortress") is set on a world whose sun has failed, forcing the above-ground creatures to take refuge in subterranean caverns. The action in Arx takes place in one of these large caves, where inhabitants from all races such as Trolls, Goblins, Dwarves, Humans, etc. have made their homes on various levels of the cave. The player awakens inside a prison cell and, after making his escape, eventually discovers his mission is to subvert and imprison the God of Destruction, Akbaa, who is trying to manifest itself in Arx.', 'arxFatalis.jpg', 'pc', 'roleplaying', 'http://youtu.be/tfTFexEyr64'),
('Fallout-New Vegas', '*CPU: 2.4 Ghz Intel Pentium 4 or equivalent processor			\r\n*RAM: 1GB System RAM (XP)/ 2GB System RAM (Vista)\r\n*VGA: Direct X 9.0c compliant video card with 256MB *RAM (NVIDIA 6800 or better/ATI X850 or better)\r\n*DX: Direct X 9.0c\r\n*OS: Windows XP/Vista\r\n			\r\n', '*CPU: Intel Core 2 Duo processor\r\n*RAM: 2 GB System RAM\r\n*VGA: Direct X 9.0c compliant video card with 512MB *RAM (NVIDIA 8800 series, ATI 3800 series)\r\n*DX: Direct X 9.0c\r\n*OS: Windows XP', 'Fallout: New Vegas takes place during the year 2281, four years after the events of Fallout 3, and 204 years after the Great War of 2077. The city of former Las Vegas (now called "New Vegas") and its surroundings are divided between various factions.', 'falloutNewVegas.jpg', 'pc', 'actionadventure', 'http://youtu.be/l-x-1fm2cq8');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
