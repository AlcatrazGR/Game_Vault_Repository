-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 27 Δεκ 2014 στις 09:52:45
-- Έκδοση διακομιστή: 5.6.20
-- Έκδοση PHP: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Βάση δεδομένων: `3071_3221_3223_3301`
--
CREATE DATABASE IF NOT EXISTS `3071_3221_3223_3301` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `3071_3221_3223_3301`;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `ACCOUNT_TYPE` varchar(7) NOT NULL,
  `USERNAME` varchar(20) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `EMAIL` varchar(40) NOT NULL,
  `SEX` varchar(7) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `USER_PHOTO` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `accounts`
--

INSERT INTO `accounts` (`ACCOUNT_TYPE`, `USERNAME`, `PASSWORD`, `EMAIL`, `SEX`, `BIRTH_DATE`, `USER_PHOTO`) VALUES
('admin', 'Alcatraz', '123456789alcatraz', 'alcatrazgr0@gmail.com', 'male', '1991-12-22', ''),
('admin', 'Alcatraz', '123456789alcatraz', 'alcatrazgr0@gmail.com', 'male', '1991-12-22', ''),
('user', 'vasilis', '123', 'sdsada@hotmail.com', 'male', '0000-00-00', 'parthenon.jpg'),
('user', 'necrolic', '125necro', 'kenzoid@hotmail.com', 'male', '2000-11-01', '10442394_10202967323236739_1295525288439634854_n.jpg'),
('admin', 'Lena', 'lena12345', 'lenaAlvarez@gmail.com', 'female', '1993-12-19', ''),
('admin', 'Lena', 'lena12345', 'lenaAlvarez@gmail.com', 'female', '1993-12-19', '');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `games`
--

DROP TABLE IF EXISTS `games`;
CREATE TABLE IF NOT EXISTS `games` (
  `GAME_TITLE` varchar(60) NOT NULL,
  `MIN_REQUIRE` longtext NOT NULL,
  `MAX_REQUIRE` longtext NOT NULL,
  `DESCRIPTION` longtext NOT NULL,
  `IMAGE` varchar(50) NOT NULL,
  `PLATFORM` varchar(15) NOT NULL,
  `CATEGORY` varchar(20) NOT NULL,
  `VIDEO_URL` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `games`
--

INSERT INTO `games` (`GAME_TITLE`, `MIN_REQUIRE`, `MAX_REQUIRE`, `DESCRIPTION`, `IMAGE`, `PLATFORM`, `CATEGORY`, `VIDEO_URL`) VALUES
('Gothic 2', '* Windows 2000/XP/XP64\r\n* 500MB RAM\r\n* Intel Pentium 4\r\n* Direct3D graphics card with at least 64MB and Shader Model 1.1', '* Windows 2000/XP/XP64\r\n* 1024MB RAM\r\n* Intel Pentium 4 / AMD CPU 2GHz or equivalent\r\n* Direct3D compatible graphics card with at least 128MB and Shader Model 1.4', 'The Nameless Hero is instructed by Xardas on the new danger, an army of evil that has gathered in the mine valley, led by dragons. Xardas sends the Hero to Lord Hagen, leader of the paladins, to retrieve the Eye of Innos, an artifact which makes it possible to speak with the dragons and learn more about their motivation. The Nameless Hero starts to the City of Khorinis and after he found a way to enter the city, he learns he has to join one of the factions – the militia, the fire mages or the mercenaries – to be permitted entrance to Lord Hagen.', 'gothic2.jpg', 'pc', 'roleplaying', 'http://youtu.be/gk6mBpSMBuk'),
('', '', '', '', '', '', '', ''),
('Gothic 3', '* Windows 2000/XP/XP64\r\n* 1024MB RAM\r\n* Intel Pentium 4 / AMD CPU 2GHz or equivalent\r\n* Direct3D compatible graphics card with at least 128MB and Shader Model 1.4', '* Windows 2000/XP/XP64\r\n* 1.5GB RAM\r\n* Intel Pentium 4 / AMD CPU 3GHz or equivalent\r\n* ATI X1600 or better, GeForce 6800 or better, at least 256MB', 'The third part opens with the Nameless Hero and his friends sailing to a new continent overrun with orcs, arriving in the Myrtana, the central region of the continent.', 'gothic3.jpg', 'pc', 'roleplaying', 'http://youtu.be/SADhUCqyd4U'),
('Arx Fatalis', '*CPU: Intel Pentium II 500 MHz\r\n*RAM: 64MB RAM	\r\n*VGA: 16MB DirectX 8.0-compatible Video Card\r\n*DX: DirectX 8				\r\n*OS: Windows 98/ME/2000/XP\r\n*HDD: 750MB Hard Drive Space\r\n*Sound: DirectX 8.0-compatible Sound Card\r\n*ODD: 4X CD-ROM		\r\n', '*CPU: Intel Pentium III 900 MHz\r\n*RAM: 256MB RAM\r\n*VGA: 32MB DirectX 8.0-compatible Video Card\r\n*DX: DirectX 8\r\n*OS: Windows 98/ME/2000/XP\r\n*HDD: 750MB Hard Drive Space\r\n*Sound: DirectX 8.0-compatible Sound Card\r\n*ODD: 4X CD-ROM', 'Arx Fatalis (lat. "fatal fortress") is set on a world whose sun has failed, forcing the above-ground creatures to take refuge in subterranean caverns. The action in Arx takes place in one of these large caves, where inhabitants from all races such as Trolls, Goblins, Dwarves, Humans, etc. have made their homes on various levels of the cave. The player awakens inside a prison cell and, after making his escape, eventually discovers his mission is to subvert and imprison the God of Destruction, Akbaa, who is trying to manifest itself in Arx.', 'arxFatalis.jpg', 'pc', 'roleplaying', 'http://youtu.be/tfTFexEyr64'),
('Fallout-New Vegas', '*CPU: 2.4 Ghz Intel Pentium 4 or equivalent processor			\r\n*RAM: 1GB System RAM (XP)/ 2GB System RAM (Vista)\r\n*VGA: Direct X 9.0c compliant video card with 256MB *RAM (NVIDIA 6800 or better/ATI X850 or better)\r\n*DX: Direct X 9.0c\r\n*OS: Windows XP/Vista\r\n			\r\n', '*CPU: Intel Core 2 Duo processor\r\n*RAM: 2 GB System RAM\r\n*VGA: Direct X 9.0c compliant video card with 512MB *RAM (NVIDIA 8800 series, ATI 3800 series)\r\n*DX: Direct X 9.0c\r\n*OS: Windows XP', 'Fallout: New Vegas takes place during the year 2281, four years after the events of Fallout 3, and 204 years after the Great War of 2077. The city of former Las Vegas (now called "New Vegas") and its surroundings are divided between various factions.', 'falloutNewVegas.jpg', 'pc', 'actionadventure', 'http://youtu.be/l-x-1fm2cq8'),
('Crysis 2', '*OS: XP/Vista/Windows 7\r\n*CPU: Intel Core 2 Duo 2Ghz, AMD Athlon 64 x2 2Ghz *or better\r\n*2 GB RAM\r\n*HDD: 9 GB\r\n*DVD ROM: 8x\r\n*GPU: NVIDIA 8800 GT 512MB Ram or better\r\n', '*OS: XP/Vista/Windows 7\r\n*CPU: Intel Core Quad Duo 2.5Ghz, AMD Athlon 64 x2 2Ghz *or better\r\n*3 GB RAM\r\n*HDD: 9 GB\r\n*DVD ROM: 8x\r\n*GPU: NVIDIA 8900 GT 512MB Ram or better', 'A United States Marine Corps Force Recon unit is deployed into New York City by the submarine USS Nautilus to extract former Crynet employee Doctor Nathan Gould, who may have vital information on combating the alien race. However, insertion goes awry - the Ceph, the alien race that is trying to destroy humanity, sinks the sub, and Force Recon Marine "Alcatraz" is left as the only apparent survivor.', 'Crysis-2.jpg', 'pc', 'action', 'http://youtu.be/aPXIhoD6odw'),
('Vtm - Bloodlines', 'CPU: Pentium III or Athlon\r\nCPU Speed: 1.2 GHz\r\nRAM: 384 MB\r\nOS: Windows 98/ME/2000/XP\r\nVideo Card: 64 MB 100% DirectX(R) 9.0c \r\nDirectX version: 9.0c \r\nFree Disk Space: 3.3 GB', 'CPU: Pentium 4 or Athlon XP\r\nCPU Speed: 1.5 GHz\r\nRAM: 512 MB\r\nOS: Windows 2000/XP\r\nDirectX version: 9.0c\r\nSound Card: Yes\r\nFree Disk Space: 5 GB\r\n', 'The game begins with the player character, an unnamed human, being killed and resurrected as a fledgling vampire. For this unauthorized act, the fledgling and their Sire are brought before the Camarilla. The Sire is executed by order of LaCroix; the fledgling is spared the same fate by the intervention of the Anarch, Nines Rodriguez, and employed by the prince. LaCroix sends the fledgling to Santa Monica to help his ghoul, Mercurio, destroy a Sabbat warehouse. Following his success the fledgling travels to downtown Los Angeles, meeting separately with Nines, LaCroix and Jack.', 'vtm-bloodlines.jpg', 'pc', 'roleplaying', 'http://youtu.be/yOPv4o9Q8Cc'),
('Anno 1503', '*CPU: Pentium-II 500 MHz processor	\r\n*RAM: 128 MB RAM		\r\n*VGA: 16MB DirectX 8.1 compatible \r\n*DX: DirectX 8.1		\r\n*OS: Windows 98, ME, 2000 or XP		\r\n*HDD: 930 MB hard drive space\r\n*Sound: DirectX 8.1 compatible sound card\r\n*ODD: 8 speed CD-ROM drive', '*CPU: Pentium-II 500 MHz processor	\r\n*RAM: 256 MB RAM		\r\n*VGA: 24MB DirectX 8.1 compatible \r\n*DX: DirectX 8.1		\r\n*OS: Windows 98, ME, 2000 or XP		\r\n*HDD: 930 MB hard drive space\r\n*Sound: DirectX 8.1 compatible sound card\r\n*ODD: 8 speed CD-ROM drive', 'Anno 1503 begins with the player in control of a ship filled with men and material searching for an island to settle. After finding a suitable site city building begins. Resources begin as food and cloth, but progress into more complicated and different goods. Eventually, citizens become Aristocrats, and require at least ten different goods and numerous services, such as access to a large church or a bathhouse.', 'anno1503.jpg', 'pc', 'strategy', 'http://youtu.be/_EeTMcbsd-M');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `ratings`
--

DROP TABLE IF EXISTS `ratings`;
CREATE TABLE IF NOT EXISTS `ratings` (
  `USERNAME` varchar(30) NOT NULL,
  `GAME_TITLE` varchar(25) NOT NULL,
  `RATE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `ratings`
--

INSERT INTO `ratings` (`USERNAME`, `GAME_TITLE`, `RATE`) VALUES
('Alcatraz', 'Gothic 2', 5),
('Alcatraz', 'Arx Fatalis', 5),
('Alcatraz', 'Fallout-New Vegas', 4),
('Alcatraz', 'Gothic 3', 5),
('Alcatraz', 'Crysis 2', 5),
('Alcatraz', 'Anno 1503', 4),
('Alcatraz', 'Vtm - Bloodlines', 5);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
